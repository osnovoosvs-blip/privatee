package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;

public class PbCommand implements CommandExecutor, TabCompleter {

    private final PrivateBlocks plugin;

    public PbCommand(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    public static String describe(PrivateBlocks plugin, Region r) {
        OfflinePlayer owner = Bukkit.getOfflinePlayer(r.owner);
        String members = r.members.isEmpty() ? "-" : r.members.stream()
                .map(u -> String.valueOf(Bukkit.getOfflinePlayer(u).getName()))
                .collect(Collectors.joining(", "));
        String flags = r.flags.entrySet().stream()
                .map(e -> e.getKey() + "=" + e.getValue())
                .sorted()
                .collect(Collectors.joining(", "));
        return plugin.msg("info",
                "%name%", r.name == null ? "-" : r.name,
                "%owner%", String.valueOf(owner.getName()),
                "%members%", members,
                "%radius%", String.valueOf(r.radius),
                "%flags%", flags);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0 && sender instanceof Player first) {
            plugin.menuGui().open(first);
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(plugin.msg("help"));
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);

        // ----- Админские команды -----
        switch (sub) {
            case "give" -> {
                if (!sender.hasPermission("privateblocks.admin")) {
                    sender.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage(plugin.msg("help"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                int amount = 1;
                if (args.length >= 4) {
                    try {
                        amount = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
                    } catch (NumberFormatException ignored) {
                    }
                }
                ItemStack item = plugin.createItem(args[2], amount);
                if (item == null) {
                    sender.sendMessage(plugin.msg("unknown-type", "%type%", args[2]));
                    return true;
                }
                HashMap<Integer, ItemStack> left = target.getInventory().addItem(item);
                left.values().forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
                sender.sendMessage(plugin.msg("given", "%amount%", String.valueOf(amount),
                        "%type%", args[2], "%player%", target.getName()));
                return true;
            }
            case "reload" -> {
                if (!sender.hasPermission("privateblocks.admin")) {
                    sender.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                sender.sendMessage(plugin.msg("reloaded"));
                return true;
            }
            default -> {
            }
        }

        // ----- Команды игрока -----
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        if (sub.equals("bypass")) {
            if (!p.hasPermission("privateblocks.admin")) {
                p.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            if (plugin.bypassSet().remove(p.getUniqueId())) {
                p.sendMessage(plugin.msg("bypass-off"));
            } else {
                plugin.bypassSet().add(p.getUniqueId());
                p.sendMessage(plugin.msg("bypass-on"));
            }
            return true;
        }

        if (sub.equals("create")) {
            handleCreate(p, args);
            return true;
        }

        if (sub.equals("menu")) {
            plugin.menuGui().open(p);
            return true;
        }

        if (sub.equals("settings") || sub.equals("admin")) {
            if (!p.isOp()) {
                p.sendMessage(plugin.msg("op-only"));
                return true;
            }
            plugin.settingsGui().openMain(p);
            return true;
        }

        if (sub.equals("list")) {
            p.sendMessage(plugin.msg("list-header"));
            for (Region r : plugin.regions().ownedBy(p.getUniqueId())) {
                p.sendMessage(PrivateBlocks.color(plugin.getConfig().getString("messages.list-entry", "")
                        .replace("%name%", r.name == null ? r.type : r.name)
                        .replace("%type%", r.type)
                        .replace("%world%", r.world)
                        .replace("%x%", String.valueOf(r.x))
                        .replace("%y%", String.valueOf(r.y))
                        .replace("%z%", String.valueOf(r.z))));
            }
            return true;
        }

        Region region = plugin.regions().getAt(p.getLocation());
        if (region == null) {
            p.sendMessage(plugin.msg("not-in-region"));
            return true;
        }

        if (sub.equals("info")) {
            p.sendMessage(describe(plugin, region));
            return true;
        }

        if (sub.equals("panel")) {
            plugin.regionGui().open(p, region);
            return true;
        }

        boolean owner = region.owner.equals(p.getUniqueId()) || plugin.canBypass(p);
        if (!owner) {
            p.sendMessage(plugin.msg("not-owner"));
            return true;
        }

        switch (sub) {
            case "add" -> {
                if (args.length < 2) {
                    p.sendMessage(plugin.msg("help"));
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                if (!t.hasPlayedBefore() && !t.isOnline()) {
                    p.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                region.members.add(t.getUniqueId());
                p.sendMessage(plugin.msg("member-added", "%player%", args[1]));
            }
            case "remove" -> {
                if (args.length < 2) {
                    p.sendMessage(plugin.msg("help"));
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                UUID id = t.getUniqueId();
                region.members.remove(id);
                p.sendMessage(plugin.msg("member-removed", "%player%", args[1]));
            }
            case "flag" -> {
                if (args.length < 3) {
                    p.sendMessage(plugin.msg("help"));
                    return true;
                }
                String flag = args[1].toLowerCase(Locale.ROOT);
                if (!Region.ALL_FLAGS.contains(flag)) {
                    p.sendMessage(plugin.msg("flag-locked", "%flags%", String.join(", ", Region.ALL_FLAGS)));
                    return true;
                }
                if (flag.equals("explosion") && !p.isOp()) {
                    p.sendMessage(plugin.msg("explosion-op-only"));
                    return true;
                }
                if (!plugin.canEditFlag(p, region, flag)) {
                    ConfigurationSection s = plugin.type(region.type);
                    List<String> editable = new ArrayList<>();
                    if (s != null) editable.addAll(s.getStringList("editable-flags"));
                    editable.remove("explosion");
                    p.sendMessage(plugin.msg("flag-locked", "%flags%", String.join(", ", editable)));
                    return true;
                }
                boolean value = Boolean.parseBoolean(args[2]);
                region.flags.put(flag, value);
                p.sendMessage(plugin.msg("flag-set", "%flag%", flag, "%value%", String.valueOf(value)));
            }
            case "delete" -> {
                plugin.regions().remove(region);
                p.getWorld().getBlockAt(region.x, region.y, region.z).setType(org.bukkit.Material.AIR);
                ItemStack item = plugin.createItem(region.type, 1);
                if (item != null) {
                    p.getInventory().addItem(item).values()
                            .forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
                }
                p.sendMessage(plugin.msg("removed"));
            }
            default -> p.sendMessage(plugin.msg("help"));
        }
        return true;
    }

    /** /rg create [название] — создаёт регион прямо под ногами (блок привата ставится на месте игрока). */
    private void handleCreate(Player p, String[] args) {
        if (!p.hasPermission("privateblocks.use")) {
            p.sendMessage(plugin.msg("no-permission"));
            return;
        }
        String typeId = plugin.getConfig().getString("create-type", "starter");
        ConfigurationSection s = plugin.type(typeId);
        if (s == null) {
            p.sendMessage(plugin.msg("unknown-type", "%type%", typeId));
            return;
        }

        String name = null;
        if (args.length > 1) {
            name = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
            if (!name.matches("[\\p{L}\\p{N} _-]{1,24}")) {
                p.sendMessage(plugin.msg("name-invalid"));
                return;
            }
            for (Region o : plugin.regions().ownedBy(p.getUniqueId())) {
                if (o.name != null && o.name.equalsIgnoreCase(name)) {
                    p.sendMessage(plugin.msg("name-taken"));
                    return;
                }
            }
        }

        org.bukkit.block.Block b = p.getLocation().getBlock();
        if (s.getStringList("disabled-worlds").contains(b.getWorld().getName())) {
            p.sendMessage(plugin.msg("disabled-world"));
            return;
        }

        UUID id = p.getUniqueId();
        if (!plugin.canBypass(p)) {
            if (!s.getBoolean("free", false)) {
                p.sendMessage(plugin.msg("not-free"));
                return;
            }
            int max = s.getInt("max-per-player", 0);
            if (max > 0 && plugin.regions().count(id, typeId) >= max) {
                p.sendMessage(plugin.msg("limit", "%max%", String.valueOf(max)));
                return;
            }
            if (plugin.claims().get(id, typeId) >= s.getInt("free-limit", 1)) {
                p.sendMessage(plugin.msg("claim-limit"));
                return;
            }
        }

        boolean spot = (b.getType().isAir() || b.isReplaceable())
                && b.getRelative(0, 1, 0).isPassable()
                && b.getRelative(0, 2, 0).isPassable();
        if (!spot) {
            p.sendMessage(plugin.msg("create-blocked"));
            return;
        }

        Region r = new Region(UUID.randomUUID(), id, b.getWorld().getName(),
                b.getX(), b.getY(), b.getZ(), s.getInt("radius", 5), typeId,
                s.getBoolean("full-height", true));
        r.name = name;
        for (Region other : plugin.regions().all()) {
            if (other.intersects(r)) {
                p.sendMessage(plugin.msg("overlap"));
                return;
            }
        }

        ConfigurationSection fs = s.getConfigurationSection("flags");
        for (String flag : Region.ALL_FLAGS) {
            r.flags.put(flag, fs != null && fs.getBoolean(flag, false));
        }

        org.bukkit.Material mat = org.bukkit.Material.matchMaterial(s.getString("material", "GOLD_BLOCK"));
        if (mat == null || !mat.isBlock()) mat = org.bukkit.Material.GOLD_BLOCK;
        b.setType(mat);
        p.teleport(p.getLocation().add(0, 1, 0)); // поднимаем игрока над блоком привата

        plugin.regions().add(r);
        plugin.claims().add(id, typeId);
        plugin.claims().save();
        plugin.regions().save();

        if (name == null) {
            p.sendMessage(plugin.msg("created", "%radius%", String.valueOf(r.radius)));
        } else {
            p.sendMessage(plugin.msg("created-named", "%name%", name, "%radius%", String.valueOf(r.radius)));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(List.of("create", "menu", "panel", "list", "info", "add", "remove", "flag", "delete", "help"));
            if (sender.hasPermission("privateblocks.admin")) out.addAll(List.of("give", "reload", "bypass"));
            if (sender.isOp()) out.add("settings");
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "give", "add", "remove" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                case "flag" -> out.addAll(Region.ALL_FLAGS);
                default -> {
                }
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "give" -> out.addAll(plugin.typeIds());
                case "flag" -> out.addAll(List.of("true", "false"));
                default -> {
                }
            }
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        return out.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(last)).collect(Collectors.toList());
    }
}
