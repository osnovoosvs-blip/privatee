package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Плашка (меню) самого привата. Открывается ПКМ по блоку привата пустой рукой
 * или командой /rg panel. Владелец добавляет и убирает тимейтов и переключает флаги.
 */
public class RegionGui implements Listener {

    private static final int[] FLAG_SLOTS = {20, 21, 22, 23, 24};
    private static final int[] MEMBER_SLOTS = {28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final int MAX_MEMBERS = MEMBER_SLOTS.length - 1; // 1 слот занят владельцем
    private static final int SLOT_INFO = 4;
    private static final int SLOT_ADD = 10;
    private static final int SLOT_BOTTOM = 49; // «Закрыть» в панели, «Назад» в выборе игрока

    private final PrivateBlocks plugin;

    public RegionGui(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    static class Holder implements InventoryHolder {
        final UUID regionId;
        final boolean picker;
        final Map<Integer, UUID> slotMap = new HashMap<>();
        Inventory inv;

        Holder(UUID regionId, boolean picker) {
            this.regionId = regionId;
            this.picker = picker;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    // ---------- Открытие ----------

    public void open(Player p, Region r) {
        if (!r.isMember(p.getUniqueId()) && !plugin.canBypass(p)) {
            p.sendMessage(plugin.msg("denied"));
            return;
        }
        Holder h = new Holder(r.id, false);
        Inventory inv = Bukkit.createInventory(h, 54, PrivateBlocks.color("&6Приват &8| &f" + name(r.owner)));
        h.inv = inv;
        renderPanel(inv, h, p, r);
        p.openInventory(inv);
    }

    private void openPicker(Player p, Region r) {
        Holder h = new Holder(r.id, true);
        Inventory inv = Bukkit.createInventory(h, 54, PrivateBlocks.color("&6Добавить тимейта"));
        h.inv = inv;

        fill(inv);
        List<Player> candidates = new ArrayList<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!r.isMember(online.getUniqueId())) candidates.add(online);
        }
        candidates.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));

        for (int i = 0; i < 45; i++) inv.setItem(i, null);
        for (int i = 0; i < candidates.size() && i < 45; i++) {
            Player c = candidates.get(i);
            inv.setItem(i, head(c, "&e" + c.getName(), "&aКлик — добавить в приват"));
            h.slotMap.put(i, c.getUniqueId());
        }
        if (candidates.isEmpty()) {
            inv.setItem(22, item(Material.BARRIER, "&cНет игроков онлайн",
                    "&7Добавить по нику:", "&f/rg add <ник>"));
        } else {
            inv.setItem(53, item(Material.PAPER, "&7Нет в списке?", "&f/rg add <ник>", "&7добавит и оффлайн-игрока"));
        }
        inv.setItem(SLOT_BOTTOM, item(Material.ARROW, "&cНазад"));
        p.openInventory(inv);
    }

    // ---------- Отрисовка панели ----------

    private void renderPanel(Inventory inv, Holder h, Player p, Region r) {
        h.slotMap.clear();
        fill(inv);
        boolean manage = canManage(p, r);

        // Информация
        ConfigurationSection ts = plugin.type(r.type);
        Material m = Material.GOLD_BLOCK;
        if (ts != null) {
            Material mm = Material.matchMaterial(ts.getString("material", "GOLD_BLOCK"));
            if (mm != null) m = mm;
        }
        int size = r.radius * 2 + 1;
        inv.setItem(SLOT_INFO, item(m, ts != null ? ts.getString("name", r.type) : r.type,
                "&7Название: &f" + (r.name == null ? "-" : r.name),
                "&7Владелец: &f" + name(r.owner),
                "&7Размер: &f" + size + "×" + size + (r.fullHeight ? " &7(вся высота)" : "×" + size),
                "&7Центр: &f" + r.x + " " + r.y + " " + r.z,
                durability(ts, r),
                "&7Тимейтов: &f" + r.members.size() + "&7/" + MAX_MEMBERS));

        // Кнопка добавления
        if (manage) {
            inv.setItem(SLOT_ADD, item(Material.EMERALD, "&aДобавить тимейта",
                    "&7Выбери игрока из онлайна", "", "&aКлик — открыть список"));
        } else {
            inv.setItem(SLOT_ADD, item(Material.GRAY_DYE, "&7Добавить тимейта",
                    "&8Только владелец может добавлять"));
        }

        // Флаги
        List<String> editable = ts == null ? List.of() : ts.getStringList("editable-flags");
        for (int i = 0; i < Region.ALL_FLAGS.size(); i++) {
            String flag = Region.ALL_FLAGS.get(i);
            boolean allowed = r.flag(flag);
            boolean canEdit = plugin.canEditFlag(p, r, flag);
            inv.setItem(FLAG_SLOTS[i], item(allowed ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
                    "&e" + flagName(flag),
                    "&7Чужим: " + (allowed ? "&aразрешено" : "&cзапрещено"),
                    canEdit ? "&aКлик — переключить"
                            : (flag.equals("explosion") ? "&8Только для операторов (/op)" : "&8Менять нельзя")));
        }

        // Участники: владелец первым, затем тимейты
        inv.setItem(MEMBER_SLOTS[0], head(Bukkit.getOfflinePlayer(r.owner), "&6" + name(r.owner), "&7Владелец"));
        int idx = 1;
        for (UUID u : r.members) {
            if (idx >= MEMBER_SLOTS.length) break;
            int slot = MEMBER_SLOTS[idx++];
            inv.setItem(slot, head(Bukkit.getOfflinePlayer(u), "&e" + name(u),
                    "&7Тимейт", manage ? "&cКлик — убрать" : ""));
            h.slotMap.put(slot, u);
        }

        inv.setItem(SLOT_BOTTOM, item(Material.BARRIER, "&cЗакрыть"));
    }

    // ---------- Клики ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;

        Region r = plugin.regions().byId(h.regionId);
        if (r == null || (!r.isMember(p.getUniqueId()) && !plugin.canBypass(p))) {
            p.closeInventory();
            return;
        }

        int slot = e.getSlot();
        boolean manage = canManage(p, r);

        if (h.picker) {
            if (slot == SLOT_BOTTOM) {
                open(p, r);
                return;
            }
            UUID target = h.slotMap.get(slot);
            if (target == null || !manage) return;
            if (r.members.size() >= MAX_MEMBERS) {
                p.sendMessage(plugin.msg("member-limit", "%max%", String.valueOf(MAX_MEMBERS)));
                return;
            }
            r.members.add(target);
            plugin.regions().save();
            p.sendMessage(plugin.msg("member-added", "%player%", name(target)));
            open(p, r);
            return;
        }

        if (slot == SLOT_BOTTOM) {
            p.closeInventory();
            return;
        }
        if (!manage) return;

        if (slot == SLOT_ADD) {
            if (r.members.size() >= MAX_MEMBERS) {
                p.sendMessage(plugin.msg("member-limit", "%max%", String.valueOf(MAX_MEMBERS)));
                return;
            }
            openPicker(p, r);
            return;
        }

        UUID member = h.slotMap.get(slot);
        if (member != null) {
            r.members.remove(member);
            plugin.regions().save();
            p.sendMessage(plugin.msg("member-removed", "%player%", name(member)));
            renderPanel(e.getInventory(), h, p, r);
            return;
        }

        ConfigurationSection ts = plugin.type(r.type);
        List<String> editable = ts == null ? List.of() : ts.getStringList("editable-flags");
        for (int i = 0; i < Region.ALL_FLAGS.size(); i++) {
            if (slot == FLAG_SLOTS[i]) {
                String flag = Region.ALL_FLAGS.get(i);
                if (!plugin.canEditFlag(p, r, flag)) return;
                r.flags.put(flag, !r.flag(flag));
                plugin.regions().save();
                renderPanel(e.getInventory(), h, p, r);
                return;
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ---------- Помощники ----------

    private String durability(ConfigurationSection ts, Region r) {
        int limit = ts == null ? 0 : ts.getInt("tnt-to-break", 0);
        if (limit <= 0) return "&7Прочность: &fне ломается от TNT";
        return "&7Прочность: &f" + Math.max(0, limit - r.tntHits) + "&7/&f" + limit + " &7TNT";
    }

    private boolean canManage(Player p, Region r) {
        return r.owner.equals(p.getUniqueId()) || plugin.canBypass(p);
    }

    private String name(UUID u) {
        String n = Bukkit.getOfflinePlayer(u).getName();
        return n == null ? "?" : n;
    }

    private String flagName(String flag) {
        return switch (flag) {
            case "build" -> "Строительство";
            case "interact" -> "Сундуки и двери";
            case "pvp" -> "PvP";
            case "explosion" -> "Взрывы";
            case "fire" -> "Огонь";
            default -> flag;
        };
    }

    private void fill(Inventory inv) {
        ItemStack bg = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        ItemStack frame = item(Material.ORANGE_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) {
            boolean edge = i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8;
            inv.setItem(i, edge ? frame : bg);
        }
    }

    private ItemStack head(OfflinePlayer owner, String name, String... lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = it.getItemMeta();
        if (meta instanceof SkullMeta sm) {
            sm.setOwningPlayer(owner);
            sm.setDisplayName(PrivateBlocks.color(name));
            List<String> l = new ArrayList<>();
            for (String line : lore) if (!line.isEmpty()) l.add(PrivateBlocks.color(line));
            sm.setLore(l);
            it.setItemMeta(sm);
        }
        return it;
    }

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(PrivateBlocks.color(name));
            List<String> l = new ArrayList<>();
            for (String line : lore) if (!line.isEmpty()) l.add(PrivateBlocks.color(line));
            meta.setLore(l);
            it.setItemMeta(meta);
        }
        return it;
    }
}
